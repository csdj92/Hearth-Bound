<?php
/**
 * The template used for displaying credits
 *
 * @package Euphony
 */
?>

<?php
/**
 * euphony_credits hook
 * @hooked euphony_footer_content - 10
 */
do_action( 'euphony_credits' );
