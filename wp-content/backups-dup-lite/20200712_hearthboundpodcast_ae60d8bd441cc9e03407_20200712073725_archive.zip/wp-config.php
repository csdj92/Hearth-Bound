<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://wordpress.org/support/article/editing-wp-config-php/

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define('AUTH_KEY',         '93b2ae619768270c0424305c2109711c3d710bce209efa1d98b93815554af195');

define('SECURE_AUTH_KEY',  '43d87917afd1ad1d7b31df39f82cd33bda8f26e38b04d871a03fe1c8fdfc9556');

define('LOGGED_IN_KEY',    '18a27181f41d058b04cd4dfe8ba068cd553f33065a0255457eac2eac4193c551');

define('NONCE_KEY',        'b3fd18ce1f43f8ec763b110a69512bb5a02f897836b7a70c6ee5140261a0baff');

define('AUTH_SALT',        '42b48bd43be6065888dbe86b0cf722e7c48a3cff285cea340a85bcf7ba6f34cd');

define('SECURE_AUTH_SALT', 'dba49fe49a6014c49df7cb1c954791402dccfe756b95ab743d0fce379558a679');

define('LOGGED_IN_SALT',   'abe7859cda7524c8c561d35d0f515539286ace967da54bf9653db65e7490a1cd');

define('NONCE_SALT',       'f21dcc8bd229e6e0e5a3cb8f6226aae45fed194c2289faeff4c6ce48f690c322');


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'wp_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the documentation.

 *

 * @link https://wordpress.org/support/article/debugging-in-wordpress/

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */

/**

 * The WP_SITEURL and WP_HOME options are configured to access from any hostname or IP address.

 * If you want to access only from an specific domain, you can modify them. For example:

 *  define('WP_HOME','http://example.com');

 *  define('WP_SITEURL','http://example.com');

 *

*/


if ( defined( 'WP_CLI' ) ) {

    $_SERVER['HTTP_HOST'] = 'localhost';

}


define('WP_SITEURL', 'http://' . $_SERVER['HTTP_HOST'] . '/wordpress');

define('WP_HOME', 'http://' . $_SERVER['HTTP_HOST'] . '/wordpress');



/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', __DIR__ . '/' );

}


/** Sets up WordPress vars and included files. */

require_once ABSPATH . 'wp-settings.php';


define('WP_TEMP_DIR', 'C:\Bitnami\wordpress-5.4.2-1/apps/wordpress/tmp');



//  Disable pingback.ping xmlrpc method to prevent Wordpress from participating in DDoS attacks

//  More info at: https://docs.bitnami.com/general/apps/wordpress/troubleshooting/xmlrpc-and-pingback/


if ( !defined( 'WP_CLI' ) ) {

    // remove x-pingback HTTP header

    add_filter('wp_headers', function($headers) {

        unset($headers['X-Pingback']);

        return $headers;

    });

    // disable pingbacks

    add_filter( 'xmlrpc_methods', function( $methods ) {

            unset( $methods['pingback.ping'] );

            return $methods;

    });

    add_filter( 'auto_update_translation', '__return_false' );

}

